set location="%~1\*.xap"
for %%a in (%location%) do (
th "%%a" -u
sleep 3
th "%%a" -%2
)
exit