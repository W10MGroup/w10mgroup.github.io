echo.
echo Screen Recorder by Nahuel
set name=%~2

set stopfile=%~1\stop.txt

set videolocation=%~1
set filetemp="%videolocation%\%name%.tmp"
set videofile="%videolocation%\%name%.mp4"

if exist "%stopfile%" del "%stopfile%"
if exist %filetemp% del %filetemp%
if exist %videofile% del %videofile%
