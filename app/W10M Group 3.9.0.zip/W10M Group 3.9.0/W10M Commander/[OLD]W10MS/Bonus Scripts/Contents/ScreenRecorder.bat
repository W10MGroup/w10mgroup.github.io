echo.
echo Screen Recorder by Nahuel

set ImgCount=1
set stopfile=%~2\stop.txt

set fileslocation=%~1\Contents\Libraries

set name=%~3

set recordlocation=%~2\%name%
set videolocation=%~2

set filetemp="%videolocation%\%name%.tmp"
set videofile="%videolocation%\%name%.mp4"

if exist "%stopfile%" del "%stopfile%"

if exist "%recordlocation%" rd /s /q "%recordlocation%"
if not exist "%recordlocation%" md "%recordlocation%"
set "Loc=%recordlocation%"
set Num=0
if not exist "%Loc%\" md "%Loc%"

::attrib +h "%Loc%"

if not exist %filetemp% echo.> %filetemp%

:recording
set CounterText=1

if %ImgCount% geq  0     (set CounterText=0000%ImgCount%)
if %ImgCount% geq  10    (set CounterText=000%ImgCount%)
if %ImgCount% geq  100   (set CounterText=00%ImgCount%)
if %ImgCount% geq  1000  (set CounterText=0%ImgCount%)
if %ImgCount% geq  10000 (set CounterText=%ImgCount%)

"%fileslocation%\screencapture" "%Loc%\Img_%CounterText%.jpg" >nul 2>&1
set /a "ImgCount=%ImgCount%+1"
if exist "%stopfile%" goto end
cls
goto recording


:end 
if exist "%stopfile%" del "%stopfile%"
if exist %filetemp% del %filetemp%
if exist %videofile% del %videofile%